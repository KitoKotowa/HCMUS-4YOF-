#ifndef _LINKED_LIST_H_
    #define _LINKED_LIST_H_

    #include <fstream>

    using namespace std;

    struct Node {
        int data;
        Node* pNext;
    };

    Node* inputListFromFile(string fileName);

    void outputListToFile(Node* pHead, string fileName);

    void deallocateList(Node* &pHead);

    #include "linkedList.cpp"
#endif
