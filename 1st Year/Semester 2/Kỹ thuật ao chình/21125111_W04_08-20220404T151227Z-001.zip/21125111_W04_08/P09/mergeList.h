#ifndef _MERGE_LIST_H_
    #define _MERGE_LIST_H_

    #include "linkedList.h"

    Node* mergeList(Node* &pHead1, Node* &pHead2);

    #include "mergeList.cpp"
#endif
