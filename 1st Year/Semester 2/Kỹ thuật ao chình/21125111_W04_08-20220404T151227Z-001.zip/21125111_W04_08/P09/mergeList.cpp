Node* mergeList(Node* &pHead1, Node* &pHead2) {
    if (pHead1 == NULL) return pHead2;
    Node* pCur = pHead1;
    while (pCur->pNext != NULL) pCur = pCur->pNext;
    pCur->pNext = pHead2;
    return pHead1;
}