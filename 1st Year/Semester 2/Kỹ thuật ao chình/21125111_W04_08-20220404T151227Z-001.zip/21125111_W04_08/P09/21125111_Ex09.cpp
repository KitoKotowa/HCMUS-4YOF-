#include <iostream>

#include "mergeList.h"

int main () {
    Node *list1 = inputListFromFile("input1.txt"), *list2 = inputListFromFile("input2.txt");
    Node* newList = mergeList(list1, list2);
    outputListToFile(newList, "output.txt");
    cout << "List saved to 'output.txt'";
    deallocateList(newList);
    return 0;
}