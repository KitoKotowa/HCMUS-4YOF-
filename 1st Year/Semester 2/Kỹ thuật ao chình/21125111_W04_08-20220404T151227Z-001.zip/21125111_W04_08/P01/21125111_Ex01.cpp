#include <iostream>

#include "removeX.h"

int main () {
    Node* list = inputListFromFile("input.txt");
    int x;
    cout << "Enter value to remove all from list in 'input.txt': ";
    cin >> x;
    list = removeX(list, x, true);
    outputListToFile(list, "output.txt");
    cout << "List saved to 'output.txt'";
    deallocateList(list);
    return 0;
}