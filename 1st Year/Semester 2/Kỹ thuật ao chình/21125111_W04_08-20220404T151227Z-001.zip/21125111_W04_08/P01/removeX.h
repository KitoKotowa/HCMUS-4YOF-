#ifndef _REMOVE_X_H_
    #define _REMOVE_X_H_

    #include "linkedList.h"

    Node* removeX (Node* &head, int x, bool removeAll);

    void excludeNode (Node* &node, Node* prevNode);

    #include "removeX.cpp"
#endif
