void excludeNode (Node* &node, Node* prevNode) {
    if (node == NULL) return;
    Node* nextNode = node->pNext;
    if (prevNode != NULL) prevNode->pNext = nextNode;
    delete node;
};

Node* removeX (Node* &head, int x, bool removeAll) {
    Node* pCur = head, *pHead = NULL, *pPrev = NULL;
    bool replaced = false;
    while ((removeAll || !replaced || pHead == NULL) && pCur != NULL) {
        Node* cursor = pCur;
        pCur = pCur->pNext;
        if ((removeAll || !replaced) && cursor->data == x) {
            excludeNode(cursor, pPrev);
            replaced = true;
        }
        else {
            if (pHead == NULL) pHead = cursor;
            pPrev = cursor;
        }
    }
    return pHead;
}

Node* removeDuplicates(Node* &head) {
    Node* pCur = head;
    while (pCur != NULL) pCur = pCur->pNext = removeX(pCur->pNext, pCur->data, true);
    return head;
}