#ifndef _REMOVE_DUPLICATES_H_
    #define _REMOVE_DUPLICATES_H_

    #include "linkedList.h"

    Node* removeX (Node* &head, int x, bool removeAll);

    void excludeNode (Node* &node, Node* prevNode);

    Node* removeDuplicates(Node* &head);

    #include "removeDuplicates.cpp"
#endif
