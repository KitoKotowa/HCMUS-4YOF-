#include <iostream>

#include "insertCustom.h"

int main () {
    Node* list = inputListFromFile("input.txt");
    list = insertCustom(list);
    outputListToFile(list, "output.txt");
    cout << "List saved to 'output.txt'";
    deallocateList(list);
    return 0;
}