#ifndef _INSERT_CUSTOM_H_
    #define _INSERT_CUSTOM_H_

    #include "linkedList.h"

    void insertAfter(Node* &pCur, Node* &newNode);

    Node* insertCustom(Node* &head);

    #include "insertCustom.cpp"
#endif
