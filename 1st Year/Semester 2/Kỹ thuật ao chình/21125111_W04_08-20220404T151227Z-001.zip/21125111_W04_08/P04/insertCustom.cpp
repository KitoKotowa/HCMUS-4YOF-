void insertAfter(Node* &pCur, Node* &newNode) {
    if (pCur == NULL || newNode == NULL) return;
    Node* pNext = pCur->pNext;
    pCur->pNext = newNode;
    newNode->pNext = pNext;
}

Node* insertCustom(Node* &head) {
    Node *dummy = new Node;
    dummy->pNext = head;
    Node *pCur = dummy;
    int i = 0;
    while (pCur->pNext != NULL) {
        Node* pInte = pCur;
        pCur = pCur->pNext;
        Node *newNode = new Node;
        newNode->data = ++i * 2;
        insertAfter(pInte, newNode);
    }
    head = dummy->pNext;
    delete dummy;
    return head;
}