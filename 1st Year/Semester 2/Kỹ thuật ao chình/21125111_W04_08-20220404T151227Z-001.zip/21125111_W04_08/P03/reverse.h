#ifndef _REVERSE_H_
    #define _REVERSE_H_

    #include "linkedList.h"

    Node* reverse(Node* &head);

    #include "reverse.cpp"
#endif
