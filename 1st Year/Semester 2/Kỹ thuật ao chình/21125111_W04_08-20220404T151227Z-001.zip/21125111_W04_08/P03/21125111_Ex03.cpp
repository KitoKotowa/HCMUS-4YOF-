#include <iostream>

#include "reverse.h"

int main () {
    Node* list = inputListFromFile("input.txt");
    list = reverse(list);
    outputListToFile(list, "output.txt");
    cout << "List saved to 'output.txt'";
    deallocateList(list);
    return 0;
}