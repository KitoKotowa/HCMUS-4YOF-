Node* reverse(Node* &head) {
    Node* pTail = NULL, *pCur = head;
    while (pCur != NULL) {
        Node* pInte = pCur;
        pCur = pCur->pNext;
        pInte->pNext = pTail;
        pTail = pInte;
    }
    return pTail;
}