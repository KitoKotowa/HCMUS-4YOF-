void insertAfter(Node* &pCur, Node* &newNode) {
    if (pCur == NULL || newNode == NULL) return;
    Node* pNext = pCur->pNext;
    pCur->pNext = newNode;
    newNode->pNext = pNext;
}

Node* sortInsert(Node* &head, int x) {
    Node *dummy = new Node;
    dummy->pNext = head;
    Node *pCur = dummy;
    Node* newNode = new Node;
    newNode->data = x;
    bool init = false;
    while (pCur->pNext != NULL && ((!init ? (init = true) : (pCur->data < x)) && pCur->pNext->data < x)) pCur = pCur->pNext;
    insertAfter(pCur, newNode);
    head = dummy->pNext;
    delete dummy;
    return head;
}