#include <iostream>

#include "sortInsert.h"

int main () {
    int x;
    cout << "Enter a number: ";
    cin >> x;
    Node *list = inputListFromFile("input.txt");
    list = sortInsert(list, x);
    outputListToFile(list, "output.txt");
    cout << "List saved to 'output.txt'";
    deallocateList(list);
    return 0;
}