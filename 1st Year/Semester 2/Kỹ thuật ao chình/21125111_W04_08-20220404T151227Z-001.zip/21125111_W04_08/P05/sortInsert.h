#ifndef _SORT_INSERT_H_
    #define _SORT_INSERT_H_

    #include "linkedList.h"

    void insertAfter(Node* &pCur, Node* &newNode);

    Node* sortInsert(Node* &head, int x);

    #include "sortInsert.cpp"
#endif
