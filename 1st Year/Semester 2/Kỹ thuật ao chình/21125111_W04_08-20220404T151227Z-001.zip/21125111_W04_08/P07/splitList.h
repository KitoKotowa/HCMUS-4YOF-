#ifndef _SPLIT_LIST_H_
    #define _SPLIT_LIST_H_

    #include "linkedList.h"

    void splitList(Node* &pHead, Node* &newHead1, Node* &newHead2);

    #include "splitList.cpp"
#endif
