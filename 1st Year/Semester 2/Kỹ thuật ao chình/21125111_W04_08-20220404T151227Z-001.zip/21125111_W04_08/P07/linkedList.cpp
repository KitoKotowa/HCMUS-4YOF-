Node* inputListFromFile(string fileName) {
    ifstream fin(fileName);
    Node *cur = new Node, *head = cur;
    int a;
    while (true) {
        fin >> a;
        if (a == 0) break;
        cur = cur->pNext = new Node;
        cur->pNext = NULL;
        cur->data = a;
    }
    Node* newHead = head->pNext;
    delete head;
    return newHead;
}

void outputListToFile(Node* pHead, string fileName, ios_base::openmode mode) {
    Node* cur = pHead;
    ofstream fout (fileName, mode);
    while (cur != NULL) {
        fout << cur->data << " ";
        cur = cur->pNext;
    }
    fout << 0;
}

void deallocateList(Node* &pHead) {
    while (pHead != NULL) {
        Node* pCur = pHead;
        pHead = pHead->pNext;
        delete pCur;
    }
}