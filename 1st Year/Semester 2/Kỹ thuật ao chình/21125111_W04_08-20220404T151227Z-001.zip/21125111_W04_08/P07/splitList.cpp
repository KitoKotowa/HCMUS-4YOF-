void splitList(Node* &pHead, Node* &newHead1, Node* &newHead2) {
    Node *newDummy1 = new Node, *newDummy2 = new Node;
    newDummy1->pNext = newDummy2->pNext = NULL;
    Node *newCur1 = newDummy1, *newCur2 = newDummy2;
    bool switched = false;
    while (pHead != NULL) {
        Node* pInte = pHead;
        pHead = pHead->pNext;
        pInte->pNext = NULL;
        if (switched) newCur2 = newCur2->pNext = pInte;
        else newCur1 = newCur1->pNext = pInte;
        switched = !switched;
    }
    newHead1 = newDummy1->pNext;
    newHead2 = newDummy2->pNext;
    delete newDummy1;
    delete newDummy2;
}