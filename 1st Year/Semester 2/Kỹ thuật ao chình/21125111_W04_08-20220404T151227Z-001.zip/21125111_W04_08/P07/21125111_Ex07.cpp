#include <iostream>

#include "splitList.h"

int main () {
    Node *list = inputListFromFile("input.txt");
    Node* newList1 = NULL, *newList2 = NULL;
    splitList(list, newList1, newList2);
    outputListToFile(newList1, "output.txt", ios_base::out);
    ofstream fout ("output.txt", ios_base::app);
    fout << "\n";
    fout.close();
    outputListToFile(newList2, "output.txt", ios_base::app);
    cout << "List saved to 'output.txt'";
    deallocateList(newList1);
    deallocateList(newList2);
    return 0;
}