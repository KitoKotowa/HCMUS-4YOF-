#include <iostream>

#include "sumList.h"

int main () {
    Node *list = inputListFromFile("input.txt");
    Node* newList = sumList(list);
    outputListToFile(newList, "output.txt");
    cout << "List saved to 'output.txt'";
    deallocateList(list);
    deallocateList(newList);
    return 0;
}