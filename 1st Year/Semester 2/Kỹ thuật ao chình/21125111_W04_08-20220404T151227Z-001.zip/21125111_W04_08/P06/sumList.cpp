Node* sumList(Node* head) {
    if (head == NULL) return NULL;
    Node *newDummy = new Node, *newCur = newDummy, *pCur = head;
    int sum = 0;
    while (pCur != NULL) {
        newCur = newCur->pNext = new Node;
        newCur->data = sum += pCur->data;
        pCur = pCur->pNext;
    }
    Node* newHead = newDummy->pNext;
    delete newDummy;
    return newHead;
}