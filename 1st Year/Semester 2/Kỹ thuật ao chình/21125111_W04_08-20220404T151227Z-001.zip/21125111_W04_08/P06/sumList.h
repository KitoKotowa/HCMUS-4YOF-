#ifndef _SUM_LIST_H_
    #define _SUM_LIST_H_

    #include "linkedList.h"

    Node* sumList(Node* pHead);

    #include "sumList.cpp"
#endif
