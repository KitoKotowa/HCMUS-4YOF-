// web_server.cpp : Defines the entry point for the console application.
//


// Ref: https://learn.microsoft.com/en-us/windows/win32/winsock/complete-server-code?source=recommendations

#undef UNICODE

#define WIN32_LEAN_AND_MEAN
#include "stdafx.h"
#include <ws2tcpip.h>
#include <stdlib.h>
#include <stdio.h>

// Need to link with Ws2_32.lib
#pragma comment (lib, "Ws2_32.lib")
// #pragma comment (lib, "Mswsock.lib")

#define DEFAULT_BUFLEN 512
#define DEFAULT_PORT "8888"

int __cdecl main(void) 
{
    WSADATA wsaData;
    int iResult;

    SOCKET ListenSocket = INVALID_SOCKET;
    SOCKET ClientSocket = INVALID_SOCKET;

    struct addrinfo *result = NULL;
    struct addrinfo hints;

    int iSendResult;
    char recvbuf[DEFAULT_BUFLEN];
    int recvbuflen = DEFAULT_BUFLEN;
    
    // Initialize Winsock
    iResult = WSAStartup(MAKEWORD(2,2), &wsaData);
    if (iResult != 0) {
        printf("WSAStartup failed with error: %d\n", iResult);
        return 1;
    }

    ZeroMemory(&hints, sizeof(hints));
    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_protocol = IPPROTO_TCP;
    hints.ai_flags = AI_PASSIVE;

    // Resolve the server address and port
    iResult = getaddrinfo(NULL, DEFAULT_PORT, &hints, &result);
    if ( iResult != 0 ) {
        printf("getaddrinfo failed with error: %d\n", iResult);
        WSACleanup();
        return 1;
    }

    // Create a SOCKET for the server to listen for client connections.
    ListenSocket = socket(result->ai_family, result->ai_socktype, result->ai_protocol);
    if (ListenSocket == INVALID_SOCKET) {
        printf("socket failed with error: %ld\n", WSAGetLastError());
        freeaddrinfo(result);
        WSACleanup();
        return 1;
    }

    // Setup the TCP listening socket
    iResult = bind( ListenSocket, result->ai_addr, (int)result->ai_addrlen);
    if (iResult == SOCKET_ERROR) {
        printf("bind failed with error: %d\n", WSAGetLastError());
        freeaddrinfo(result);
        closesocket(ListenSocket);
        WSACleanup();
        return 1;
    }

    freeaddrinfo(result);

    iResult = listen(ListenSocket, SOMAXCONN);
    if (iResult == SOCKET_ERROR) {
        printf("listen failed with error: %d\n", WSAGetLastError());
        closesocket(ListenSocket);
        WSACleanup();
        return 1;
    }

    // Accept a client socket
	do
	{
		printf("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n");
		printf("Waiting for connection from client\n");
		ClientSocket = accept(ListenSocket, NULL, NULL);
		if (ClientSocket == INVALID_SOCKET) {
			printf("accept failed with error: %d\n", WSAGetLastError());
			closesocket(ListenSocket);
			WSACleanup();
			return 1;
		}
		char buffer[1000];
		int size_buff = sizeof buffer;
		memset(buffer, 0, size_buff);
		iResult = recv(ClientSocket, buffer, size_buff, 0);
		printf("Request data: \n%s\n", buffer);
        if (iResult > 0) {
            printf("==>Bytes received: %d\n", iResult);
		}

		char data[] = "<h1 style='color: red;'>Welcome to </h1><h3 style='color: #137ceb;'>Faculty of Information Technology (FIT) - HCMC University of Science</h3>227 Nguyen Van Cu, Dist 5 HCMC";
		memset(buffer, 0, size_buff);
		//  data =                            <header>                                   +<body>
		int j = sprintf_s(buffer, size_buff, "HTTP/1.1 200 OK\r\nContent-Length:%d\r\n\r\n%s", strlen(data), data);
		printf("############################################\n");
		printf("Reponse data: \n%s\n", buffer);

		iSendResult = send( ClientSocket, buffer, size_buff, 0 );
		if (iSendResult == SOCKET_ERROR) {
			printf("send failed with error: %d\n", WSAGetLastError());
			closesocket(ClientSocket);
		}
		printf("==>Bytes sent: %d\n", iSendResult);
		closesocket(ClientSocket);
	}while(1);
    // cleanup
    //closesocket(ClientSocket);
    WSACleanup();

    return 0;
}