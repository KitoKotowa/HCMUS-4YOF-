#include "syscall.h"

int main() {
    Close(2);

    Halt();
    return 0;
}